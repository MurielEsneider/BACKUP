//array.length
const color = ["blue", "red", "yellow"]
let tamaño = color.length
console.log(tamaño);  //Cuenta los valores

const colors2 = ["red", "purple", "green", "yellow"];
let size = colors2.length
console.log(size); //Cuenta los valores
//array.length





//array.toString
const sabor = ["vainilla", "chocolate","mango","fresa"]
document.getElementById("sabores").innerHTML = sabor.toString()

const sabores2 = ["Maracuyá", "chocolate","vainilla","fresa"]
document.getElementById("sabores2").innerHTML = sabor.toString() //SEPARA POR COMAS
//array.toString








//array.at
// con parentesis ()
const frutas = ["mango", "sandia", "manzana", "pera"];
let fruta = frutas.at(2);
console.log(fruta);
//con llaves
const animales = ["zorro", "sapo", "murcielago", "perro"];
let animal = animales[3];
console.log(animal);
//array.at








//array join
const nombres = ["Maria", "Jose","Ricardo"];
document.getElementById("demo").innerHTML = nombres.join(" - ");

const nombres2 = ["Mia", "Anuel","Ricardo"];
document.getElementById("demo2").innerHTML = nombres2.join(" * ");
//array join






//array pops
const apellidos = ["Peréz","Ortega", "Castillo"];
document.getElementById("demo3").innerHTML = apellidos;
apellidos.pop();
document.getElementById("demo4").innerHTML = apellidos;


const apellidos2 = ["Muriel","Castro", "Penagos"];
document.getElementById("demo5").innerHTML = apellidos2,
document.getElementById("demo6").innerHTML = apellidos2.pop();

//consola
const apellidos3 = ["Muriel","Castro", "Penagos"];
let apellido3 = apellidos3.pop();
console.log(apellido3)
//array pops 






// array push
const transp =["moto", "bus", "carro"];
document.getElementById("demo7").innerHTML = transp;
transp.push("avion");
document.getElementById("demo8").innerHTML = transp;
//
const transp2 =["moto", "bus", "carro"];
let length  = transp2.push("avion");
console.log (length);
// array push






//array shift
const juegos = ["halo", "Faf", "minecraft", "zelda"]
juegos.shift()  //quita el primero
document.getElementById("juegos").innerHTML = juegos


const juegos1 = ["mario", "warzone", "COD"];
document.getElementById("juegos1").innerHTML = juegos1,
document.getElementById("juegos1.1").innerHTML = juegos1.shift();  // deja únicamente le primero

const juegos2 = ["mario", "warzone", "COD"]
let juego2 = juegos2.shift() // deja únicamente le primero por consola
console.log(juego2)   
// array shift








//array unshift
const marcas = ["luisVotton","GUCCI", "PRADA"];
marcas.unshift("Valentino");
document.getElementById("demo9").innerHTML = marcas;          // agrega nuevo valor al inicio 

const marcas2 = ["luisVotton","GUCCI", "PRADA"];
document.getElementById("demo10").innerHTML = marcas2.unshift("Valentino"); // devuelve la nueva longitud de la matriz:
//array unshift








//array delte
const calzado = ["NIKE", "ADIDAS", "PUMA"];
document.getElementById("demo12").innerHTML= calzado;
delete calzado[0];  
document.getElementById("demo13").innerHTML=calzado;  //elimina la posicion seleccionada



const calzados2 = ["NIKE", "ADIDAS", "PUMA"];
document.getElementById("demo14").innerHTML= calzados2;
delete calzados2[2];
document.getElementById("demo15").innerHTML= calzados2;  //elimina la posicion seleccionada
//array delte









